

<div class="container-fluid footer">
	<div class="container">
		<div class="row">
			<p style="text-align: center;">Copyright &copy; My School Projects</a></p>
		</div>
	</div>
</div>
	<script src="<?php echo $path['siteUrl']; ?>/lib/jquery-3.1.1.min.js"></script>
	<script src="<?php echo $path['siteUrl']; ?>/js/custom.js"></script>
</body>
</html>