$(document).ready(function(){
	// Initiate Tiny MCE
	tinymce.init({
	  selector: 'textarea',  // change this value according to your HTML
	  auto_focus: 'element1'
	});
});
