

		<script src="../lib/jquery-3.1.1.min.js"></script>
		<script src="../lib/tinymce/js/tinymce/tinymce.min.js"></script>
		<script src="../js/custom.js"></script>
		</div>
	</div>
</body>
</html>
